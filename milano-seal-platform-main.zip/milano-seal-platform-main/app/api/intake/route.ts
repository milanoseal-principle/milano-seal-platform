import { NextRequest, NextResponse } from 'next/server'
import { createClient } from '@/lib/supabase/server'
import { normalizeMatter, validateMatter, riskScore } from '@/lib/validation'
import { determineLaneAndPrice } from '@/lib/pricing'
import { generateInvoice } from '@/lib/invoice'
import { validateCompliance } from '@/lib/compliance'

function generateDealId(): string {
  const year = new Date().getFullYear()
  const rand = Math.floor(Math.random() * 9000) + 1000
  return `MS-${year}-${rand}`
}

export async function POST(req: NextRequest) {
  try {
    const raw = await req.json()

    // 1. Normalize — prevent undefined crashes
    const data = normalizeMatter(raw)

    // 2. Validate — blocking checks
    try {
      validateMatter(data)
    } catch (err: any) {
      return NextResponse.json({ error: err.message, code: err.message }, { status: 400 })
    }

    // 3. Compliance — wire country rules, force apostille if required
    const country = data.country || 'United States'
    let complianceResult = null
    try {
      complianceResult = validateCompliance({
        country,
        documentType: data.document_type || 'general',
        executionType: data.mobile ? 'mobile' : 'ron',
        destinationCountry: country,
      })
      // Force apostille if compliance requires it
      if (complianceResult.requiresApostille && !data.apostille) {
        data.apostille = true
      }
      // Force witness if required
      if (complianceResult.warnings.some((w: string) => w.toLowerCase().includes('witness'))) {
        if (!data.witnesses || data.witnesses === 0) data.witnesses = 1
      }
    } catch {}

    // 4. Pricing
    const pricing = determineLaneAndPrice(data)

    // 5. Invoice
    const invoice = generateInvoice(pricing.total)

    // 6. Risk score
    const decline_risk = riskScore(data)

    // 7. Deal ID
    const deal_id = generateDealId()

    // 8. Persist to Supabase
    const supabase = await createClient()
    const { data: deal, error } = await supabase
      .from('deals')
      .insert([{
        id:                    deal_id,
        client_name:           data.name || '',
        email:                 data.email || '',
        phone:                 data.phone || '',
        country,
        document:              data.document_type || '',
        notes:                 data.notes || '',
        execution_tier:        pricing.lane,
        amount:                pricing.total,
        status:                'awaiting_payment',
        payment_status:        'pending',
        payment_method:        'stripe',
        invoice_status:        'proforma',
        invoice_subtotal:      invoice.subtotal,
        invoice_retainer:      invoice.retainer,
        invoice_balance:       invoice.balance,
        invoice_valid_until:   new Date(invoice.valid_until).toISOString(),
        compliance_result:     JSON.stringify(complianceResult),
        decline_risk,
        followup_24h:          false,
        followup_72h:          false,
        follow_up_active:      true,
        followup_schedule:     JSON.stringify(['48h', '96h', '7d']),
        requires_apostille:    data.apostille,
        destination_country:   country,
        score:                 50,
        source:                'web',
      }])
      .select()
      .single()

    if (error) {
      console.error('DB insert error:', error)
      // Return response even if DB fails (graceful)
    }

    // 9. Response
    return NextResponse.json({
      success:         true,
      deal_id,
      lane:            pricing.lane,
      estimated_value: pricing.total,
      invoice,
      payment_options: invoice.payment_options,
      payment_link:    null, // wire Stripe here when STRIPE_SECRET_KEY is set
      execution_stage: 'Awaiting Payment',
      compliance_result: complianceResult,
      decline_risk,
      deal,
    })

  } catch (err: any) {
    console.error('Intake error:', err)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}
