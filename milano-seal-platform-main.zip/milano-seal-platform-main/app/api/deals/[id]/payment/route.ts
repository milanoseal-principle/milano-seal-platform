import { NextRequest, NextResponse } from 'next/server'
import { createClient } from '@/lib/supabase/server'
import { requirePaid, validateStatusTransition } from '@/lib/gate'

export async function POST(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params
    const body = await req.json()
    const supabase = await createClient()

    const { payment_method, payment_status, payment_reference, payment_amount_received } = body

    const validMethods = ['stripe', 'wise', 'zelle', 'venmo', 'cash_app', 'apple_cash']
    if (!validMethods.includes(payment_method)) {
      return NextResponse.json({ error: 'Invalid payment method' }, { status: 400 })
    }

    if (!['pending', 'partial', 'paid'].includes(payment_status)) {
      return NextResponse.json({ error: 'Invalid payment status' }, { status: 400 })
    }

    // Fetch current deal
    const { data: deal, error: fetchErr } = await supabase
      .from('deals')
      .select('*')
      .eq('id', id)
      .single()

    if (fetchErr || !deal) {
      return NextResponse.json({ error: 'Deal not found' }, { status: 404 })
    }

    const updateData: Record<string, unknown> = {
      payment_method,
      payment_status,
      payment_reference: payment_reference || null,
      payment_amount_received: payment_amount_received || 0,
    }

    // If paid, advance deal status and flip invoice
    if (payment_status === 'paid') {
      updateData.invoice_status = 'paid'
      updateData.status = 'scheduled'
    }

    const { data: updated, error: updateErr } = await supabase
      .from('deals')
      .update(updateData)
      .eq('id', id)
      .select()
      .single()

    if (updateErr) {
      return NextResponse.json({ error: 'Failed to update payment' }, { status: 500 })
    }

    return NextResponse.json({ success: true, deal: updated })
  } catch (err: any) {
    console.error('Payment update error:', err)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}
