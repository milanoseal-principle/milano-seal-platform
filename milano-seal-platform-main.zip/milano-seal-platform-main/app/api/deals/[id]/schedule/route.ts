import { NextRequest, NextResponse } from 'next/server'
import { createClient } from '@/lib/supabase/server'
import { requirePaid } from '@/lib/gate'

export async function POST(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params
    const body = await req.json()
    const supabase = await createClient()

    const { data: deal, error } = await supabase
      .from('deals')
      .select('*')
      .eq('id', id)
      .single()

    if (error || !deal) {
      return NextResponse.json({ error: 'Deal not found' }, { status: 404 })
    }

    // HARD GATE: Payment required
    try {
      requirePaid(deal)
    } catch {
      return NextResponse.json(
        { error: 'PAYMENT_REQUIRED_BEFORE_EXECUTION', message: 'Payment must be received before scheduling can begin.' },
        { status: 402 }
      )
    }

    const { data: updated } = await supabase
      .from('deals')
      .update({
        status: 'scheduled',
        execution_date: body.execution_date || null,
      })
      .eq('id', id)
      .select()
      .single()

    return NextResponse.json({ success: true, deal: updated })
  } catch (err: any) {
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}
