import { NextRequest, NextResponse } from 'next/server'
import { createClient } from '@/lib/supabase/server'
import { requirePaid } from '@/lib/gate'

export async function POST(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params
    const supabase = await createClient()

    const { data: deal, error } = await supabase
      .from('deals')
      .select('*')
      .eq('id', id)
      .single()

    if (error || !deal) return NextResponse.json({ error: 'Deal not found' }, { status: 404 })

    try { requirePaid(deal) } catch {
      return NextResponse.json(
        { error: 'PAYMENT_REQUIRED_BEFORE_EXECUTION' },
        { status: 402 }
      )
    }

    const { data: updated } = await supabase
      .from('deals')
      .update({ status: 'in_execution' })
      .eq('id', id)
      .select()
      .single()

    return NextResponse.json({ success: true, deal: updated })
  } catch {
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}
