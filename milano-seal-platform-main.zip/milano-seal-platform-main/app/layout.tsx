import type { Metadata } from 'next'
import { Geist, Geist_Mono } from 'next/font/google'
import { Analytics } from '@vercel/analytics/next'
import './globals.css'

const _geist = Geist({ subsets: ["latin"] });
const _geistMono = Geist_Mono({ subsets: ["latin"] });

export const metadata = {
  title: "The Milano Seal™ — International Document Execution",
  description: "U.S. document execution and apostille liaison. Precision, discretion, and procedural control for international matters.",
  metadataBase: new URL("https://themilanoseal.com"),
  icons: {
    icon: [
      { url: "/favicon-32x32.png", sizes: "32x32", type: "image/png" },
      { url: "/favicon-16x16.png", sizes: "16x16", type: "image/png" },
    ],
    apple: [
      { url: "/apple-touch-icon.png", sizes: "180x180", type: "image/png" },
    ],
    other: [
      { rel: "manifest", url: "/site.webmanifest" },
    ],
  },
  openGraph: {
    title: "The Milano Seal™",
    description: "International document execution and apostille coordination.",
    url: "https://themilanoseal.com",
    siteName: "The Milano Seal",
    images: [
      {
        url: "https://themilanoseal.com/og-image.png",
        width: 1200,
        height: 630,
        alt: "The Milano Seal — International Document Execution",
      },
    ],
    locale: "en_US",
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
    title: "The Milano Seal™",
    description: "U.S. document execution and apostille liaison.",
    images: ["https://themilanoseal.com/og-image.png"],
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="en">
      <body className="font-sans antialiased">
        {children}
        {process.env.NODE_ENV === 'production' && <Analytics />}
      </body>
    </html>
  )
}
