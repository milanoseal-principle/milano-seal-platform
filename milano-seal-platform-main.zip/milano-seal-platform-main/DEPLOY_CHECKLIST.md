# Milano Seal OS — Deploy Checklist

## 1. Supabase
- [ ] Run scripts/001_create_deals_table.sql
- [ ] Run scripts/002_os_migration.sql
- [ ] Confirm all columns exist in deals table
- [ ] Set Row Level Security to allow service role full access

## 2. Vercel Environment Variables
- [ ] NEXT_PUBLIC_SUPABASE_URL
- [ ] NEXT_PUBLIC_SUPABASE_ANON_KEY
- [ ] SUPABASE_SERVICE_ROLE_KEY
- [ ] NEXT_PUBLIC_SITE_URL
- [ ] STRIPE_SECRET_KEY (when live)
- [ ] STRIPE_WEBHOOK_SECRET (when live)
- [ ] ANTHROPIC_API_KEY (for AI modules)

## 3. Stripe (when ready)
- [ ] Create product in Stripe Dashboard
- [ ] Set up webhook → /api/webhook/stripe
- [ ] Events to listen: checkout.session.completed

## 4. API Routes — all live after deploy
- POST /api/intake             — Full OS intake with pricing + invoice
- GET  /api/deals              — Dashboard feed
- GET  /api/deals/:id          — Deal detail
- PATCH /api/deals/:id         — Status updates
- POST /api/deals/:id/payment  — Manual payment confirmation (operator)
- POST /api/deals/:id/schedule — Schedule (payment gate enforced)
- POST /api/deals/:id/execute  — Start execution (payment gate enforced)
- POST /api/deals/:id/apostille — Dispatch apostille (payment gate enforced)
- POST /api/webhook/stripe     — Stripe payment webhook

## 5. Test Sequence
1. Submit intake (Italy, apostille) → verify awaiting_payment returned
2. Submit intake (Colorado, no apostille, 1 doc) → verify 150 pricing
3. Mark deal paid via /api/deals/:id/payment → verify status flips to scheduled
4. Attempt /api/deals/:id/schedule without payment → verify 402 error
5. Trigger Stripe webhook → verify auto-status update

## 6. Public site — payment section displays:
- Accepted methods listed (NO handles/usernames shown)
- "Additional payment methods available upon request."
- Schedule button disabled until payment_status = paid
