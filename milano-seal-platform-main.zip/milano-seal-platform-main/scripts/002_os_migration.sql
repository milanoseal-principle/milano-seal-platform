-- Milano Seal OS — Schema Migration
-- Run in Supabase SQL Editor

ALTER TABLE public.deals
  ADD COLUMN IF NOT EXISTS invoice_status       text DEFAULT 'proforma',
  ADD COLUMN IF NOT EXISTS invoice_subtotal     numeric,
  ADD COLUMN IF NOT EXISTS invoice_retainer     numeric,
  ADD COLUMN IF NOT EXISTS invoice_balance      numeric,
  ADD COLUMN IF NOT EXISTS invoice_valid_until  timestamptz,
  ADD COLUMN IF NOT EXISTS payment_method       text DEFAULT 'stripe',
  ADD COLUMN IF NOT EXISTS payment_reference    text,
  ADD COLUMN IF NOT EXISTS payment_amount_received numeric DEFAULT 0,
  ADD COLUMN IF NOT EXISTS compliance_result    text,
  ADD COLUMN IF NOT EXISTS decline_risk         text DEFAULT 'NORMAL',
  ADD COLUMN IF NOT EXISTS follow_up_active     boolean DEFAULT true,
  ADD COLUMN IF NOT EXISTS followup_schedule    text DEFAULT '["48h","96h","7d"]',
  ADD COLUMN IF NOT EXISTS execution_date       timestamptz,
  ADD COLUMN IF NOT EXISTS requires_apostille   boolean DEFAULT false,
  ADD COLUMN IF NOT EXISTS destination_country  text,
  ADD COLUMN IF NOT EXISTS score                int DEFAULT 50,
  ADD COLUMN IF NOT EXISTS source               text DEFAULT 'web';

-- Add constraints
ALTER TABLE public.deals
  DROP CONSTRAINT IF EXISTS deals_invoice_status_check;
ALTER TABLE public.deals
  ADD CONSTRAINT deals_invoice_status_check
  CHECK (invoice_status IN ('proforma','final','paid'));

ALTER TABLE public.deals
  DROP CONSTRAINT IF EXISTS deals_payment_method_check;
ALTER TABLE public.deals
  ADD CONSTRAINT deals_payment_method_check
  CHECK (payment_method IN ('stripe','wise','zelle','venmo','cash_app','apple_cash'));

-- Allow custom deal IDs (MS-YYYY-NNNN)
ALTER TABLE public.deals
  ALTER COLUMN id TYPE text;

-- Index on status for dashboard queries
CREATE INDEX IF NOT EXISTS idx_deals_status_payment
  ON public.deals(status, payment_status);

SELECT 'Migration complete. ' || count(*) || ' deals in table.' as result
FROM public.deals;
