// PAYMENT GATE — Hard enforcement. Runs before scheduling, execution, apostille.
// Milano Seal SOP: Payment required before scheduling.

export interface DealRecord {
  id: string
  payment_status: string
  status: string
}

export function requirePaid(deal: DealRecord): void {
  if (deal.payment_status !== 'paid') {
    throw new Error('PAYMENT_REQUIRED_BEFORE_EXECUTION')
  }
}

// Status machine: valid forward transitions only
const VALID_TRANSITIONS: Record<string, string[]> = {
  new:                 ['reviewing'],
  reviewing:           ['quoted'],
  quoted:              ['awaiting_payment'],
  awaiting_payment:    ['scheduled'],
  scheduled:           ['in_execution'],
  in_execution:        ['apostille', 'completed'],
  apostille:           ['shipped'],
  shipped:             ['completed'],
  completed:           [],
  lost:                [],
}

export function validateStatusTransition(from: string, to: string, adminOverride = false): void {
  if (adminOverride) return
  const allowed = VALID_TRANSITIONS[from] || []
  if (!allowed.includes(to)) {
    throw new Error(`INVALID_STATUS_TRANSITION: ${from} -> ${to}`)
  }
}

// Normalize backend status names to canonical UI statuses
const STATUS_MAP: Record<string, string> = {
  'intake_received':     'new',
  'under_review':        'reviewing',
  'apostille_processing':'apostille',
}

export function normalizeStatus(status: string): string {
  return STATUS_MAP[status] || status
}
